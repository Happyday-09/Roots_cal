import { useState } from "react";
import { 네비게이션바 } from "./components/메뉴/메뉴모음";
import 홈페이지 from "./pages/홈/홈페이지";
import { 로그인페이지, 회원가입페이지 } from "./pages/인증/인증페이지";
import { 목표설정페이지, 지출업로드페이지 } from "./pages/목표설정/목표설정페이지";
import { 분석결과페이지, 마이페이지 } from "./pages/분석/분석결과페이지";

export default function App() {
  const [page,     setPage]     = useState("main");
  const [goalData, setGoalData] = useState(null);

  const navigate = (p, data) => {
    if (data) setGoalData(data);
    setPage(p);
    window.scrollTo(0, 0);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#F3F4F6", fontFamily: "'Noto Sans KR', 'Apple SD Gothic Neo', sans-serif" }}>
      <네비게이션바 page={page} navigate={navigate} />
      {page === "main"    && <홈페이지        navigate={navigate} />}
      {page === "login"   && <로그인페이지     navigate={navigate} />}
      {page === "signup"  && <회원가입페이지   navigate={navigate} />}
      {page === "goal"    && <목표설정페이지   navigate={navigate} />}
      {page === "upload"  && <지출업로드페이지 navigate={navigate} goalData={goalData} />}
      {page === "result"  && <분석결과페이지   navigate={navigate} goalData={goalData} />}
      {page === "mypage"  && <마이페이지       navigate={navigate} goalData={goalData} />}
    </div>
  );
}
