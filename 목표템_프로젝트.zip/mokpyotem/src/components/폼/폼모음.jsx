import { useState } from "react";
import { 색상 } from "../../tokens/색상";

// ─── 기본 입력 필드 ───────────────────────────────────────────────
export function 입력필드({ label, type = "text", placeholder, value, onChange, error }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ marginBottom: 18 }}>
      <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 7 }}>
        {label}
      </label>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: "100%", padding: "12px 16px",
          border: `1.5px solid ${error ? "#F87171" : focused ? 색상.main : "#E5E7EB"}`,
          borderRadius: 10, fontSize: 14, outline: "none",
          boxSizing: "border-box", color: "#111827", background: "#fff",
          fontFamily: "inherit",
        }}
      />
      {error && <p style={{ fontSize: 12, color: "#EF4444", margin: "5px 0 0" }}>{error}</p>}
    </div>
  );
}

// ─── 금액 입력 필드 ───────────────────────────────────────────────
export function 금액입력필드({ label, value, onChange }) {
  const fmt = (v) => v.replace(/[^0-9]/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ marginBottom: 22 }}>
      <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>
        {label}
      </label>
      <div style={{ position: "relative" }}>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(fmt(e.target.value))}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: "100%", padding: "12px 48px 12px 16px",
            border: `1.5px solid ${focused ? 색상.main : "#E5E7EB"}`,
            borderRadius: 10, fontSize: 15, outline: "none",
            boxSizing: "border-box", color: "#111827", fontFamily: "inherit",
          }}
        />
        <span style={{ position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)", fontSize: 15, color: "#6B7280" }}>원</span>
      </div>
    </div>
  );
}

// ─── 비밀번호 강도 표시 필드 ──────────────────────────────────────
export function 비밀번호필드({ value, onChange, error }) {
  const strength = () => {
    if (!value) return null;
    if (value.length < 6) return { label: "약함",  color: "#EF4444", width: "33%" };
    if (value.length < 10 || !/[^a-zA-Z0-9]/.test(value))
      return { label: "보통", color: "#F59E0B", width: "66%" };
    return { label: "강함", color: 색상.main, width: "100%" };
  };
  const s = strength();

  return (
    <div style={{ marginBottom: 18 }}>
      <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 7 }}>비밀번호</label>
      <input
        type="password"
        placeholder="8자 이상 입력"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          width: "100%", padding: "12px 16px",
          border: `1.5px solid ${error ? "#F87171" : s ? s.color : "#E5E7EB"}`,
          borderRadius: 10, fontSize: 14, outline: "none",
          boxSizing: "border-box", color: "#111827", fontFamily: "inherit",
        }}
      />
      {s && (
        <div style={{ marginTop: 8 }}>
          <div style={{ height: 4, background: "#E5E7EB", borderRadius: 999, overflow: "hidden" }}>
            <div style={{ height: "100%", width: s.width, background: s.color, borderRadius: 999, transition: "width 0.3s" }} />
          </div>
          <p style={{ fontSize: 11, color: s.color, margin: "4px 0 0", fontWeight: 600 }}>비밀번호 강도: {s.label}</p>
        </div>
      )}
      {error && <p style={{ fontSize: 12, color: "#EF4444", margin: "5px 0 0" }}>{error}</p>}
    </div>
  );
}

// ─── 약관 동의 체크박스 ───────────────────────────────────────────
export function 약관동의박스({ agree, agreeMarketing, onChangeAgree, onChangeMarketing, error }) {
  const allChecked = agree && agreeMarketing;
  const handleAll = (checked) => {
    onChangeAgree(checked);
    onChangeMarketing(checked);
  };

  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ background: "#F9FAFB", borderRadius: 12, padding: "16px", border: "1px solid #E5E7EB" }}>
        <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", marginBottom: 12 }}>
          <input type="checkbox" checked={allChecked} onChange={(e) => handleAll(e.target.checked)}
            style={{ width: 16, height: 16, accentColor: 색상.main }} />
          <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>전체 동의</span>
        </label>
        <div style={{ borderTop: "1px solid #E5E7EB", paddingTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
          {[
            { label: "서비스 이용약관 동의",  required: true,  checked: agree,            onChange: onChangeAgree },
            { label: "마케팅 정보 수신 동의", required: false, checked: agreeMarketing,    onChange: onChangeMarketing },
          ].map((item) => (
            <label key={item.label} style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
              <input type="checkbox" checked={item.checked} onChange={(e) => item.onChange(e.target.checked)}
                style={{ width: 15, height: 15, accentColor: 색상.main }} />
              <span style={{ fontSize: 13, color: "#374151" }}>
                <span style={{ color: item.required ? 색상.main : "#9CA3AF", marginRight: 4, fontWeight: 700 }}>
                  {item.required ? "[필수]" : "[선택]"}
                </span>
                {item.label}
              </span>
            </label>
          ))}
        </div>
      </div>
      {error && <p style={{ fontSize: 12, color: "#EF4444", margin: "6px 0 0" }}>{error}</p>}
    </div>
  );
}

// ─── 파일 드롭존 ──────────────────────────────────────────────────
export function 파일드롭존({ file, onFile }) {
  const [dragging, setDragging] = useState(false);
  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) onFile(f); }}
        onClick={() => document.getElementById("파일입력").click()}
        style={{
          border: `2px dashed ${file || dragging ? 색상.main : "#D1D5DB"}`,
          borderRadius: 14, padding: "52px 24px", textAlign: "center",
          cursor: "pointer", background: file || dragging ? "#F0FDF4" : "#FAFAFA",
          transition: "all 0.2s",
        }}
      >
        <div style={{ fontSize: 42, marginBottom: 12 }}>{file ? "✅" : "📄"}</div>
        {file
          ? <><p style={{ fontSize: 15, fontWeight: 600, color: 색상.main, margin: "0 0 4px" }}>{file.name}</p>
              <p style={{ fontSize: 13, color: "#6B7280", margin: 0 }}>파일이 선택되었습니다</p></>
          : <><p style={{ fontSize: 15, color: "#374151", margin: "0 0 6px", fontWeight: 500 }}>파일을 드래그하거나 클릭하여 업로드</p>
              <p style={{ fontSize: 13, color: "#9CA3AF", margin: 0 }}>CSV, 엑셀 파일만 가능</p></>
        }
        <input id="파일입력" type="file" accept=".csv,.xlsx,.xls" style={{ display: "none" }}
          onChange={(e) => { if (e.target.files[0]) onFile(e.target.files[0]); }} />
      </div>
      <p style={{ fontSize: 12, color: "#9CA3AF", marginTop: 10 }}>※ 카드사나 은행에서 다운로드한 내역 파일을 사용해주세요.</p>
    </div>
  );
}
