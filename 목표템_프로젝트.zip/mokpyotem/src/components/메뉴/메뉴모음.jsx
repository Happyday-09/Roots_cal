import { 색상 } from "../../tokens/색상";
import { 기본버튼 } from "../버튼/버튼모음";

// ─── 상단 네비게이션 바 ───────────────────────────────────────────
export function 네비게이션바({ page, navigate }) {
  const 메뉴목록 = [
    { label: "홈",            dest: "main"   },
    { label: "사용자 정보 입력", dest: "goal"   },
    { label: "목표템 보기",    dest: "mypage" },
  ];

  return (
    <nav style={{
      background: "#fff", borderBottom: "1px solid #E5E7EB",
      position: "sticky", top: 0, zIndex: 100,
    }}>
      <div style={{
        maxWidth: 1100, margin: "0 auto", padding: "0 24px",
        height: 64, display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        {/* 로고 + 메뉴 */}
        <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
          <button
            onClick={() => navigate("main")}
            style={{
              display: "flex", alignItems: "center", gap: 8,
              background: "none", border: "none", cursor: "pointer",
              fontSize: 20, fontWeight: 800, color: "#111827", fontFamily: "inherit",
            }}
          >
            <span style={{
              width: 32, height: 32, background: 색상.main, borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "#fff", fontSize: 16,
            }}>📈</span>
            목표템
          </button>

          <div style={{ display: "flex", gap: 4 }}>
            {메뉴목록.map(({ label, dest }) => (
              <메뉴버튼
                key={label}
                label={label}
                active={page === dest}
                onClick={() => navigate(dest)}
              />
            ))}
          </div>
        </div>

        {/* 로그인 / 회원가입 */}
        <div style={{ display: "flex", gap: 8 }}>
          <기본버튼 onClick={() => navigate("login")} variant="outline" style={{ padding: "8px 20px", fontSize: 13 }}>로그인</기본버튼>
          <기본버튼 onClick={() => navigate("signup")} style={{ padding: "8px 20px", fontSize: 13 }}>회원가입</기본버튼>
        </div>
      </div>
    </nav>
  );
}

// ─── 개별 메뉴 버튼 ───────────────────────────────────────────────
export function 메뉴버튼({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: "none", border: "none", cursor: "pointer",
        fontSize: 14, fontFamily: "inherit",
        color:      active ? 색상.main : "#374151",
        fontWeight: active ? 700 : 400,
        padding: "8px 12px",
        borderBottom: active ? `2px solid ${색상.main}` : "2px solid transparent",
      }}
    >
      {label}
    </button>
  );
}

// ─── 사이드바 메뉴 (마이페이지) ──────────────────────────────────
export function 사이드바메뉴({ items, active, onSelect }) {
  return (
    <div>
      {items.map((m) => (
        <button
          key={m.label}
          onClick={() => onSelect(m.label)}
          style={{
            width: "100%", display: "flex", alignItems: "center", gap: 10,
            padding: "12px 16px", borderRadius: 10,
            background: active === m.label ? "#F0FDF4" : "transparent",
            border: "none", cursor: "pointer", fontFamily: "inherit",
            color:      active === m.label ? 색상.dark : "#374151",
            fontSize: 14, fontWeight: active === m.label ? 700 : 400,
            marginBottom: 4, textAlign: "left",
          }}
        >
          <span>{m.icon}</span>
          {m.label}
        </button>
      ))}
    </div>
  );
}

// ─── 스텝 진행 바 (목표설정 흐름) ────────────────────────────────
export function 스텝바({ current }) {
  const steps = ["목표 설정", "지출 업로드", "분석 중", "결과 확인"];
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 40 }}>
      {steps.map((s, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <div style={{
              width: 36, height: 36, borderRadius: "50%",
              background: i <= current ? 색상.main : "#E5E7EB",
              color:      i <= current ? "#fff" : "#9CA3AF",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 13, fontWeight: 700,
            }}>
              {i < current ? "✓" : i + 1}
            </div>
            <span style={{
              fontSize: 11, whiteSpace: "nowrap",
              color:      i <= current ? 색상.main : "#9CA3AF",
              fontWeight: i <= current ? 600 : 400,
            }}>{s}</span>
          </div>
          {i < steps.length - 1 && (
            <div style={{
              width: 56, height: 2, margin: "0 6px", marginBottom: 20,
              background: i < current ? 색상.main : "#E5E7EB",
            }} />
          )}
        </div>
      ))}
    </div>
  );
}
