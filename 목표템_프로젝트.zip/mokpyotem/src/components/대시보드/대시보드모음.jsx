// ─── 도넛 차트 (분석 결과 페이지) ────────────────────────────────
export function 도넛차트({ data }) {
  const cx = 80, cy = 80, r = 58;
  let offset = 0;

  const polar = (angle) => {
    const rad = (angle - 90) * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const arc = (startPct, endPct) => {
    const s = polar(startPct * 3.6);
    const e = polar(endPct * 3.6);
    return `M ${s.x} ${s.y} A ${r} ${r} 0 ${endPct - startPct > 50 ? 1 : 0} 1 ${e.x} ${e.y}`;
  };

  return (
    <svg width={160} height={160} viewBox="0 0 160 160">
      {data.map((s, i) => {
        const start = offset;
        offset += s.pct;
        return (
          <path key={i} d={arc(start, start + s.pct)}
            fill="none" stroke={s.color} strokeWidth={22} />
        );
      })}
      <circle cx={cx} cy={cy} r={46} fill="#fff" />
      <text x={cx} y={cy - 5} textAnchor="middle" fontSize={11} fill="#9CA3AF">총 지출</text>
      <text x={cx} y={cy + 13} textAnchor="middle" fontSize={15} fontWeight="700" fill="#111827">30만원</text>
    </svg>
  );
}

// ─── 소비 범례 아이템 ─────────────────────────────────────────────
export function 범례아이템({ label, pct, color, amount }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 10, height: 10, borderRadius: "50%", background: color }} />
        <span style={{ fontSize: 13, color: "#374151" }}>{label} {pct}%</span>
      </div>
      <span style={{ fontSize: 12, color: "#6B7280" }}>{amount.toLocaleString()}원</span>
    </div>
  );
}

// ─── 진행률 바 ────────────────────────────────────────────────────
export function 진행률바({ pct, color = "#22C55E" }) {
  return (
    <div style={{ height: 10, background: "#E5E7EB", borderRadius: 999, overflow: "hidden" }}>
      <div style={{
        height: "100%", width: `${pct}%`,
        background: color, borderRadius: 999,
        transition: "width 1s ease",
      }} />
    </div>
  );
}

// ─── 분석 히스토리 행 ─────────────────────────────────────────────
export function 히스토리행({ date, result }) {
  return (
    <div style={{
      display: "flex", justifyContent: "space-between", alignItems: "center",
      padding: "14px 16px", background: "#F9FAFB",
      borderRadius: 10, border: "1px solid #E5E7EB", marginBottom: 10,
    }}>
      <span style={{ fontSize: 14, color: "#374151" }}>{date}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 13, color: "#9CA3AF" }}>→</span>
        <span style={{ fontSize: 14, fontWeight: 700, color: "#22C55E" }}>{result}</span>
      </div>
    </div>
  );
}
