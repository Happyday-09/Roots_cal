export default function Navbar({ page, navigate }) {
  const navItems = [
    { label: "홈", key: "main" },
    { label: "서비스 소개", key: "main" },
    { label: "이용 방법", key: "main" },
    { label: "고객센터", key: "main" },
  ];

  return (
    <nav style={{
      background: "#fff",
      borderBottom: "1px solid #E5E7EB",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      <div style={{
        maxWidth: 1100,
        margin: "0 auto",
        padding: "0 24px",
        height: 64,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
          <button
            onClick={() => navigate("main")}
            style={{
              display: "flex", alignItems: "center", gap: 8,
              background: "none", border: "none", cursor: "pointer",
              fontSize: 20, fontWeight: 700, color: "#111827",
            }}
          >
            <span style={{
              width: 32, height: 32, background: "#22C55E", borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "#fff", fontSize: 16,
            }}>📈</span>
            목표템
          </button>
          <div style={{ display: "flex", gap: 8 }}>
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => navigate(item.key)}
                style={{
                  background: "none", border: "none", cursor: "pointer",
                  fontSize: 14, color: page === "main" && item.label === "홈" ? "#22C55E" : "#374151",
                  fontWeight: page === "main" && item.label === "홈" ? 600 : 400,
                  padding: "8px 12px",
                  borderBottom: page === "main" && item.label === "홈" ? "2px solid #22C55E" : "2px solid transparent",
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button style={{
            padding: "8px 20px", borderRadius: 8,
            border: "1px solid #D1D5DB",
            background: "#fff", color: "#374151",
            fontSize: 14, cursor: "pointer", fontWeight: 500,
          }}>로그인</button>
          <button
            onClick={() => navigate("goal")}
            style={{
              padding: "8px 20px", borderRadius: 8,
              border: "none", background: "#22C55E",
              color: "#fff", fontSize: 14, cursor: "pointer", fontWeight: 600,
            }}
          >회원가입</button>
        </div>
      </div>
    </nav>
  );
}
