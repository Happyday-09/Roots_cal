import { 색상 } from "../../tokens/색상";

// ─── 기본 버튼 ────────────────────────────────────────────────────
export function 기본버튼({ children, onClick, variant = "primary", style = {} }) {
  const base = {
    padding: "12px 24px", borderRadius: 10, fontSize: 14,
    fontWeight: 700, cursor: "pointer", border: "none",
    transition: "opacity 0.15s", fontFamily: "inherit",
  };
  const variants = {
    primary: { background: 색상.main, color: "#fff" },
    outline: { background: "#fff", color: "#374151", border: "1.5px solid #D1D5DB" },
    ghost:   { background: "transparent", color: 색상.dark, border: "none" },
  };
  return (
    <button
      onClick={onClick}
      style={{ ...base, ...variants[variant], ...style }}
      onMouseEnter={e => e.currentTarget.style.opacity = "0.85"}
      onMouseLeave={e => e.currentTarget.style.opacity = "1"}
    >
      {children}
    </button>
  );
}

// ─── 소셜 로그인 버튼 ─────────────────────────────────────────────
export function 소셜버튼({ emoji, label, color, bg }) {
  return (
    <button
      style={{
        width: "100%", padding: "12px", borderRadius: 10,
        border: "1.5px solid #E5E7EB", background: bg || "#fff",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
        fontSize: 14, fontWeight: 600, color: color || "#374151",
        cursor: "pointer", marginBottom: 10, fontFamily: "inherit",
      }}
      onMouseEnter={e => e.currentTarget.style.opacity = "0.85"}
      onMouseLeave={e => e.currentTarget.style.opacity = "1"}
    >
      <span style={{ fontSize: 18 }}>{emoji}</span>
      {label}
    </button>
  );
}

// ─── 전체 너비 버튼 ───────────────────────────────────────────────
export function 전체너비버튼({ children, onClick, disabled, style = {} }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        width: "100%", padding: "14px", borderRadius: 10,
        background: disabled ? 색상.mid : 색상.main,
        color: "#fff", border: "none", fontSize: 15,
        fontWeight: 700, cursor: disabled ? "not-allowed" : "pointer",
        fontFamily: "inherit", ...style,
      }}
    >
      {children}
    </button>
  );
}
