import { 색상 } from "../../tokens/색상";

// ─── 기본 카드 ────────────────────────────────────────────────────
export function 기본카드({ children, style = {} }) {
  return (
    <div style={{
      background: "#fff", borderRadius: 20, padding: "28px",
      boxShadow: "0 2px 16px rgba(0,0,0,0.05)", ...style,
    }}>
      {children}
    </div>
  );
}

// ─── 기능 소개 카드 (메인 페이지) ────────────────────────────────
export function 기능카드({ icon, title, desc }) {
  return (
    <div style={{
      background: "#F9FAFB", border: "1px solid #E5E7EB",
      borderRadius: 18, padding: "30px 24px", textAlign: "center",
    }}>
      <div style={{ fontSize: 38, marginBottom: 14 }}>{icon}</div>
      <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 10px" }}>{title}</h3>
      <p style={{ fontSize: 14, color: "#6B7280", lineHeight: 1.6, margin: 0, whiteSpace: "pre-line" }}>{desc}</p>
    </div>
  );
}

// ─── 절약 팁 카드 (분석 결과 페이지) ─────────────────────────────
export function 팁카드({ icon, text }) {
  return (
    <div style={{
      background: "#F0FDF4", borderRadius: 14, padding: "20px",
      display: "flex", gap: 14, alignItems: "flex-start",
    }}>
      <span style={{ fontSize: 30 }}>{icon}</span>
      <p style={{ fontSize: 14, color: 색상.text, margin: 0, lineHeight: 1.6, fontWeight: 500 }}>{text}</p>
    </div>
  );
}

// ─── 목표 진행 카드 (마이페이지) ─────────────────────────────────
export function 목표카드({ itemName, amount, savedPct = 40, expectedPeriod = "5개월" }) {
  const saved = Math.round(amount * (savedPct / 100));
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 20, padding: "20px",
      background: "#F9FAFB", borderRadius: 14, border: "1px solid #E5E7EB",
    }}>
      <div style={{
        width: 60, height: 60, borderRadius: 14, background: "#1F2937",
        display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30,
      }}>🎧</div>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 4px" }}>{itemName}</p>
        <p style={{ fontSize: 15, color: "#374151", margin: "0 0 12px" }}>{amount.toLocaleString()}원</p>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
          <span style={{ fontSize: 12, color: "#9CA3AF" }}>달성 예상 기간: {expectedPeriod}</span>
          <span style={{ fontSize: 12, color: 색상.main, fontWeight: 700 }}>{savedPct}%</span>
        </div>
        <div style={{ height: 8, background: "#E5E7EB", borderRadius: 999, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${savedPct}%`, background: 색상.main, borderRadius: 999 }} />
        </div>
        <p style={{ fontSize: 11, color: "#9CA3AF", margin: "6px 0 0" }}>
          {saved.toLocaleString()}원 / {amount.toLocaleString()}원
        </p>
      </div>
    </div>
  );
}
