import { useState } from "react";

const menuItems = [
  { icon: "📊", label: "대시보드" },
  { icon: "🎯", label: "목표 관리" },
  { icon: "📄", label: "지출 내역" },
  { icon: "📈", label: "분석 결과" },
  { icon: "⚙️", label: "설정" },
];

const history = [
  { date: "2024.06.01 분석", result: "5개월 예상" },
  { date: "2024.05.01 분석", result: "6개월 예상" },
  { date: "2024.04.01 분석", result: "7개월 예상" },
];

export default function MyPage({ navigate, goalData }) {
  const [activeMenu, setActiveMenu] = useState("목표 관리");
  const goal = goalData || { itemName: "게이밍 헤드셋", amount: 300000, period: "5개월" };

  return (
    <div style={{ background: "#F3F4F6", minHeight: "calc(100vh - 64px)", padding: "32px 24px" }}>
      <div style={{ maxWidth: 1000, margin: "0 auto", display: "grid", gridTemplateColumns: "220px 1fr", gap: 20 }}>
        {/* Sidebar */}
        <div style={{ background: "#fff", borderRadius: 20, padding: "28px 16px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)", height: "fit-content" }}>
          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <div style={{
              width: 60, height: 60, borderRadius: "50%", background: "#DCFCE7",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 28, margin: "0 auto 10px",
            }}>👤</div>
            <p style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: 0 }}>홍길동</p>
            <p style={{ fontSize: 12, color: "#9CA3AF", margin: "4px 0 0" }}>hong@example.com</p>
          </div>
          <div>
            {menuItems.map((m) => (
              <button
                key={m.label}
                onClick={() => setActiveMenu(m.label)}
                style={{
                  width: "100%", display: "flex", alignItems: "center", gap: 10,
                  padding: "12px 16px", borderRadius: 10,
                  background: activeMenu === m.label ? "#F0FDF4" : "transparent",
                  border: "none", cursor: "pointer",
                  color: activeMenu === m.label ? "#16A34A" : "#374151",
                  fontSize: 14, fontWeight: activeMenu === m.label ? 600 : 400,
                  marginBottom: 4, textAlign: "left",
                }}
              >
                <span>{m.icon}</span>
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Current Goal */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "28px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 20px" }}>나의 목표</h3>
            <div style={{
              display: "flex", alignItems: "center", gap: 20,
              padding: "20px", background: "#F9FAFB", borderRadius: 14,
              border: "1px solid #E5E7EB",
            }}>
              <div style={{
                width: 56, height: 56, borderRadius: 14,
                background: "#1F2937", display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 28,
              }}>🎧</div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 4px" }}>{goal.itemName}</p>
                <p style={{ fontSize: 15, color: "#374151", margin: "0 0 10px" }}>{goal.amount.toLocaleString()}원</p>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 12, color: "#9CA3AF" }}>달성 예상 기간: 5개월</span>
                  <span style={{ fontSize: 12, color: "#22C55E", fontWeight: 600 }}>40%</span>
                </div>
                <div style={{ height: 8, background: "#E5E7EB", borderRadius: 999, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: "40%", background: "#22C55E", borderRadius: 999 }} />
                </div>
                <p style={{ fontSize: 11, color: "#9CA3AF", margin: "6px 0 0" }}>
                  {Math.round(goal.amount * 0.4).toLocaleString()}원 / {goal.amount.toLocaleString()}원
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate("goal")}
              style={{
                marginTop: 16, padding: "10px 20px",
                background: "#22C55E", color: "#fff",
                border: "none", borderRadius: 8,
                fontSize: 13, fontWeight: 600, cursor: "pointer",
              }}
            >+ 새 목표 추가</button>
          </div>

          {/* Analysis History */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "28px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 20px" }}>최근 분석 결과</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {history.map((h, i) => (
                <div key={i} style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "14px 16px",
                  background: "#F9FAFB", borderRadius: 10,
                  border: "1px solid #E5E7EB",
                }}>
                  <span style={{ fontSize: 14, color: "#374151" }}>{h.date}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 13, color: "#9CA3AF" }}>→</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: "#22C55E" }}>{h.result}</span>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate("result")}
              style={{
                width: "100%", marginTop: 16, padding: "12px",
                background: "#fff", color: "#374151",
                border: "1.5px solid #D1D5DB", borderRadius: 10,
                fontSize: 14, fontWeight: 600, cursor: "pointer",
              }}
            >전체 보기</button>
          </div>
        </div>
      </div>
    </div>
  );
}
