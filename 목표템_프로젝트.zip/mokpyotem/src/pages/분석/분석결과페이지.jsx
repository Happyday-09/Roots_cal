import { useState } from "react";
import { 색상 } from "../../tokens/색상";
import { 기본버튼 } from "../../components/버튼/버튼모음";
import { 기본카드, 팁카드 } from "../../components/카드/카드모음";
import { 사이드바메뉴 } from "../../components/메뉴/메뉴모음";
import { 도넛차트, 범례아이템, 진행률바, 히스토리행 } from "../../components/대시보드/대시보드모음";

// ─── 분석 결과 페이지 ─────────────────────────────────────────────
const 소비데이터 = [
  { label: "식비",     pct: 40, color: "#22C55E", amount: 120000 },
  { label: "카페/간식", pct: 20, color: "#86EFAC", amount:  60000 },
  { label: "교통",     pct: 15, color: "#FCD34D", amount:  45000 },
  { label: "쇼핑",     pct: 15, color: "#F87171", amount:  45000 },
  { label: "기타",     pct: 10, color: "#93C5FD", amount:  30000 },
];
const 절약팁목록 = [
  { icon: "🍜", text: "배달비를 월 5만원 줄이면 3개월 내 목표 달성 가능!" },
  { icon: "☕", text: "카페 이용을 주 2회 줄이면 월 2만원 절약 가능!" },
  { icon: "📦", text: "불필요한 구독 서비스를 점검해보세요! 월 1만원 이상 절약 가능!" },
];

export function 분석결과페이지({ navigate, goalData }) {
  const goal = goalData || { itemName: "게이밍 헤드셋", amount: 300000 };
  const saved = Math.round(goal.amount * 0.4);
  const pct   = Math.round((saved / goal.amount) * 100);

  return (
    <div style={{ background: "#F3F4F6", minHeight: "calc(100vh - 64px)", padding: "40px 24px" }}>
      <div style={{ maxWidth: 920, margin: "0 auto" }}>
        {/* 상단 바 */}
        <기본카드 style={{ marginBottom: 18, padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 18, fontWeight: 800, color: "#111827" }}>📈 목표템</span>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <기본버튼 variant="ghost" onClick={() => navigate("main")}   style={{ padding: "6px 12px", fontSize: 13 }}>홈</기본버튼>
            <기본버튼 variant="ghost" onClick={() => navigate("mypage")} style={{ padding: "6px 12px", fontSize: 13, color: 색상.main, fontWeight: 700 }}>마이페이지</기본버튼>
            <div style={{ width: 34, height: 34, borderRadius: "50%", background: "#E5E7EB", display: "flex", alignItems: "center", justifyContent: "center" }}>👤</div>
          </div>
        </기본카드>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          {/* 목표 달성 예측 */}
          <기본카드>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: "0 0 18px" }}>목표 달성 예측</h3>
            <div style={{ marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: "#9CA3AF" }}>목표 금액</span>
              <p style={{ fontSize: 24, fontWeight: 800, color: "#111827", margin: "4px 0" }}>{goal.amount.toLocaleString()}원</p>
            </div>
            <div style={{ marginBottom: 16 }}>
              <span style={{ fontSize: 12, color: "#9CA3AF" }}>현재 모은 금액</span>
              <p style={{ fontSize: 17, fontWeight: 600, color: "#374151", margin: "4px 0" }}>{saved.toLocaleString()}원 ({pct}%)</p>
            </div>
            <진행률바 pct={pct} />
            <div style={{ borderTop: "1px solid #F3F4F6", paddingTop: 18, marginTop: 22 }}>
              <span style={{ fontSize: 12, color: "#9CA3AF" }}>목표 달성 예상 기간</span>
              <p style={{ fontSize: 48, fontWeight: 900, color: 색상.main, margin: "4px 0" }}>5개월</p>
              <p style={{ fontSize: 12, color: "#6B7280" }}>현재 소비 패턴으로는 5개월 후 목표를 달성할 수 있어요!</p>
            </div>
          </기본카드>

          {/* 소비 패턴 */}
          <기본카드>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: "0 0 18px" }}>소비 패턴 (월 평균)</h3>
            <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
              <도넛차트 data={소비데이터} />
              <div style={{ flex: 1 }}>
                {소비데이터.map((s) => <범례아이템 key={s.label} {...s} />)}
              </div>
            </div>
          </기본카드>

          {/* AI 절약 추천 */}
          <기본카드 style={{ gridColumn: "1 / -1" }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: "0 0 18px" }}>AI 절약 추천</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
              {절약팁목록.map((tip, i) => <팁카드 key={i} {...tip} />)}
            </div>
          </기본카드>
        </div>

        <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
          <기본버튼 variant="outline" onClick={() => navigate("goal")}   style={{ padding: "12px 24px" }}>새 목표 설정</기본버튼>
          <기본버튼             onClick={() => navigate("mypage")} style={{ padding: "12px 24px" }}>마이페이지로 →</기본버튼>
        </div>
      </div>
    </div>
  );
}

// ─── 마이페이지 ───────────────────────────────────────────────────
const 사이드바메뉴목록 = [
  { icon: "📊", label: "대시보드" },
  { icon: "🎯", label: "목표 관리" },
  { icon: "📄", label: "지출 내역" },
  { icon: "📈", label: "분석 결과" },
  { icon: "⚙️", label: "설정" },
];
const 히스토리목록 = [
  { date: "2024.06.01 분석", result: "5개월 예상" },
  { date: "2024.05.01 분석", result: "6개월 예상" },
  { date: "2024.04.01 분석", result: "7개월 예상" },
];

export function 마이페이지({ navigate, goalData }) {
  const [activeMenu, setActiveMenu] = useState("목표 관리");
  const goal = goalData || { itemName: "게이밍 헤드셋", amount: 300000 };

  return (
    <div style={{ background: "#F3F4F6", minHeight: "calc(100vh - 64px)", padding: "36px 24px" }}>
      <div style={{ maxWidth: 1000, margin: "0 auto", display: "grid", gridTemplateColumns: "230px 1fr", gap: 24 }}>
        {/* 사이드바 */}
        <기본카드 style={{ padding: "28px 16px", height: "fit-content" }}>
          <div style={{ textAlign: "center", marginBottom: 28, paddingBottom: 24, borderBottom: "1px solid #E5E7EB" }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: 색상.light, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, margin: "0 auto 12px" }}>👤</div>
            <p style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: 0 }}>홍길동</p>
            <p style={{ fontSize: 12, color: "#9CA3AF", margin: "4px 0 0" }}>hong@example.com</p>
          </div>
          <사이드바메뉴 items={사이드바메뉴목록} active={activeMenu} onSelect={setActiveMenu} />
        </기본카드>

        {/* 콘텐츠 */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <기본카드>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: "0 0 18px" }}>나의 목표</h3>
            <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "20px", background: "#F9FAFB", borderRadius: 14, border: "1px solid #E5E7EB" }}>
              <div style={{ width: 60, height: 60, borderRadius: 14, background: "#1F2937", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30 }}>🎧</div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 4px" }}>{goal.itemName}</p>
                <p style={{ fontSize: 15, color: "#374151", margin: "0 0 12px" }}>{goal.amount.toLocaleString()}원</p>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 12, color: "#9CA3AF" }}>달성 예상 기간: 5개월</span>
                  <span style={{ fontSize: 12, color: 색상.main, fontWeight: 700 }}>40%</span>
                </div>
                <진행률바 pct={40} />
                <p style={{ fontSize: 11, color: "#9CA3AF", margin: "6px 0 0" }}>{Math.round(goal.amount * 0.4).toLocaleString()}원 / {goal.amount.toLocaleString()}원</p>
              </div>
            </div>
            <기본버튼 onClick={() => navigate("goal")} style={{ marginTop: 16, padding: "10px 20px", fontSize: 13 }}>+ 새 목표 추가</기본버튼>
          </기본카드>

          <기본카드>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: "0 0 18px" }}>최근 분석 결과</h3>
            {히스토리목록.map((h, i) => <히스토리행 key={i} {...h} />)}
            <기본버튼 variant="outline" onClick={() => navigate("result")} style={{ width: "100%", padding: "12px", marginTop: 6 }}>전체 보기</기본버튼>
          </기본카드>
        </div>
      </div>
    </div>
  );
}
