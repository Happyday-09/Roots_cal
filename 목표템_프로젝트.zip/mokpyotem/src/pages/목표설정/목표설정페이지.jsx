import { useState } from "react";
import { 색상 } from "../../tokens/색상";
import { 기본버튼, 전체너비버튼 } from "../../components/버튼/버튼모음";
import { 기본카드 } from "../../components/카드/카드모음";
import { 금액입력필드, 파일드롭존 } from "../../components/폼/폼모음";
import { 스텝바 } from "../../components/메뉴/메뉴모음";

// ─── 목표 설정 페이지 ─────────────────────────────────────────────
export function 목표설정페이지({ navigate }) {
  const [itemName, setItemName] = useState("");
  const [amount,   setAmount]   = useState("300,000");
  const [period,   setPeriod]   = useState("3개월");

  const handleNext = () => {
    if (!itemName.trim()) return alert("물건 이름을 입력해주세요.");
    navigate("upload", { itemName, amount: parseInt(amount.replace(/,/g, "")) || 300000, period });
  };

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "60px 24px" }}>
      <div style={{ width: "100%", maxWidth: 520 }}>
        <스텝바 current={0} />
        <기본카드>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: "#111827", margin: "0 0 32px" }}>목표하는 물건을 입력해주세요</h2>

          <div style={{ marginBottom: 22 }}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>물건 이름</label>
            <input
              type="text" placeholder="예) 게이밍 헤드셋" value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              onFocus={(e) => e.target.style.borderColor = 색상.main}
              onBlur={(e) => e.target.style.borderColor = "#E5E7EB"}
              style={{ width: "100%", padding: "12px 16px", border: "1.5px solid #E5E7EB", borderRadius: 10, fontSize: 15, outline: "none", boxSizing: "border-box", color: "#111827", fontFamily: "inherit" }}
            />
          </div>

          <금액입력필드 label="목표 금액" value={amount} onChange={setAmount} />

          <div style={{ marginBottom: 36 }}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>원하는 기간</label>
            <select value={period} onChange={(e) => setPeriod(e.target.value)}
              style={{ width: "100%", padding: "12px 16px", border: "1.5px solid #E5E7EB", borderRadius: 10, fontSize: 15, outline: "none", background: "#fff", color: "#111827", cursor: "pointer", fontFamily: "inherit" }}>
              {["1개월","2개월","3개월","4개월","5개월","6개월","12개월"].map(p => <option key={p}>{p}</option>)}
            </select>
          </div>

          <전체너비버튼 onClick={handleNext} style={{ fontSize: 16 }}>다음</전체너비버튼>
        </기본카드>
      </div>
    </div>
  );
}

// ─── 지출 업로드 페이지 ───────────────────────────────────────────
export function 지출업로드페이지({ navigate, goalData }) {
  const [tab,       setTab]       = useState("file");
  const [file,      setFile]      = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const handleAnalyze = () => {
    setAnalyzing(true);
    setTimeout(() => navigate("result", goalData), 2000);
  };

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "60px 24px" }}>
      <div style={{ width: "100%", maxWidth: 560 }}>
        <스텝바 current={1} />
        <기본카드>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: "#111827", margin: "0 0 28px" }}>지출 내역을 입력해주세요</h2>

          {/* 탭 전환 */}
          <div style={{ display: "flex", marginBottom: 28, border: "1.5px solid #E5E7EB", borderRadius: 10, overflow: "hidden" }}>
            {[["file", "파일 업로드"], ["direct", "직접 입력"]].map(([t, label]) => (
              <button key={t} onClick={() => setTab(t)}
                style={{ flex: 1, padding: "12px", background: tab === t ? 색상.main : "#fff", color: tab === t ? "#fff" : "#374151", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 600, fontFamily: "inherit" }}>
                {label}
              </button>
            ))}
          </div>

          {tab === "file"
            ? <파일드롭존 file={file} onFile={setFile} />
            : <textarea placeholder={"날짜, 금액, 카테고리 형식으로 입력해주세요\n예) 2024-01-01, 12000, 카페"} rows={8}
                style={{ width: "100%", padding: "14px 16px", border: "1.5px solid #E5E7EB", borderRadius: 10, fontSize: 14, outline: "none", resize: "vertical", boxSizing: "border-box", color: "#111827", lineHeight: 1.6, fontFamily: "inherit" }} />
          }

          {analyzing && (
            <div style={{ textAlign: "center", padding: "16px 0", color: 색상.main, fontWeight: 700 }}>⏳ 분석 중...</div>
          )}

          <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
            <기본버튼 onClick={() => navigate("goal")} variant="outline" style={{ flex: 1, padding: "13px" }}>이전</기본버튼>
            <전체너비버튼 onClick={handleAnalyze} disabled={analyzing} style={{ flex: 2 }}>분석 시작</전체너비버튼>
          </div>
        </기본카드>
      </div>
    </div>
  );
}
