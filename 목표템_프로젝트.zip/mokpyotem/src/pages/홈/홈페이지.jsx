import { 색상 } from "../../tokens/색상";
import { 기본버튼 } from "../../components/버튼/버튼모음";
import { 기능카드 } from "../../components/카드/카드모음";

const 기능목록 = [
  { icon: "🥧", title: "지출 분석",  desc: "지출 내역을 분석해\n소비 패턴을 파악해요." },
  { icon: "📅", title: "목표 예측",  desc: "목표 금액 달성까지\n걸리는 기간을 알려줘요." },
  { icon: "💡", title: "절약 추천",  desc: "지출을 줄일 수 있는\n맞춤 팁을 제공해요." },
  { icon: "📊", title: "시각화",     desc: "그래프와 표로 쉽고\n직관적으로 보여줘요." },
];

const 플로우목록 = [
  { icon: "🏠", label: "메인 페이지" },
  { icon: "👤", label: "로그인/회원가입" },
  { icon: "🎯", label: "목표 설정" },
  { icon: "📄", label: "지출 내역 업로드" },
  { icon: "📊", label: "분석 결과" },
  { icon: "👤", label: "마이페이지" },
];

export default function 홈페이지({ navigate }) {
  return (
    <div>
      {/* 히어로 */}
      <div style={{ background: "#fff", padding: "0 24px 60px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 64, gap: 48 }}>
          <div style={{ flex: 1 }}>
            <h1 style={{ fontSize: 46, fontWeight: 800, color: "#111827", lineHeight: 1.25, margin: "0 0 18px" }}>
              얼마나 모으면<br />
              <span style={{ color: 색상.main }}>갖고 싶은 걸</span> 살 수 있을까?
            </h1>
            <p style={{ fontSize: 16, color: "#6B7280", lineHeight: 1.8, margin: "0 0 32px" }}>
              지출 내역을 분석해서 목표 달성 기간을 예측하고<br />
              절약 방법을 추천해드려요.
            </p>
            <기본버튼 onClick={() => navigate("login")} style={{ fontSize: 16, padding: "14px 32px" }}>
              분석 시작하기 →
            </기본버튼>
          </div>
          <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
            <div style={{ position: "relative", width: 340, height: 280 }}>
              <div style={{ width: 210, height: 210, background: 색상.light, borderRadius: "50%", position: "absolute", top: 35, left: 65, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 88 }}>🐷</div>
              <div style={{ position: "absolute", top: 0, right: 10, width: 110, height: 140, background: "#fff", borderRadius: 16, border: `2px solid ${색상.main}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 7, boxShadow: "0 4px 24px rgba(34,197,94,0.18)" }}>
                <div style={{ fontSize: 30 }}>📋</div>
                {[60, 50, 55].map((w, i) => (
                  <div key={i} style={{ width: w, height: 6, background: [색상.light, "#BBF7D0", 색상.mid][i], borderRadius: 3 }} />
                ))}
              </div>
              <div style={{ position: "absolute", bottom: 8, right: 36, width: 48, height: 48, background: "#FCD34D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, boxShadow: "0 2px 10px rgba(0,0,0,0.12)" }}>₩</div>
              {[{ top: 0, left: 200 }, { top: 130, left: 20 }, { top: 60, left: 320 }].map((pos, i) => (
                <div key={i} style={{ position: "absolute", ...pos, color: 색상.main, fontSize: [14, 10, 12][i], opacity: 0.7 }}>✦</div>
              ))}
            </div>
          </div>
        </div>

        {/* 기능 카드 */}
        <div style={{ maxWidth: 1100, margin: "52px auto 0", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
          {기능목록.map((f) => <기능카드 key={f.title} {...f} />)}
        </div>
      </div>

      {/* 이용 흐름 */}
      <div style={{ background: "#F9FAFB", padding: "72px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <h2 style={{ textAlign: "center", fontSize: 30, fontWeight: 800, color: "#111827", marginBottom: 52 }}>이렇게 사용해요</h2>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
            {플로우목록.map((step, i, arr) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 68, height: 68, background: 색상.light, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30 }}>{step.icon}</div>
                  <span style={{ fontSize: 12, color: "#374151", fontWeight: 500, textAlign: "center" }}>{step.label}</span>
                </div>
                {i < arr.length - 1 && <span style={{ fontSize: 20, color: "#9CA3AF", marginBottom: 26 }}>→</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      <footer style={{ background: "#111827", padding: "28px 24px", color: "#9CA3AF", fontSize: 13, textAlign: "center" }}>
        © 2024 목표템. All rights reserved.
      </footer>
    </div>
  );
}
