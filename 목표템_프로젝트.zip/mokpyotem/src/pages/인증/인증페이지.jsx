import { useState } from "react";
import { 색상 } from "../../tokens/색상";
import { 기본버튼, 소셜버튼, 전체너비버튼 } from "../../components/버튼/버튼모음";
import { 기본카드 } from "../../components/카드/카드모음";
import { 입력필드, 비밀번호필드, 약관동의박스 } from "../../components/폼/폼모음";

// ─── 로그인 페이지 ────────────────────────────────────────────────
export function 로그인페이지({ navigate }) {
  const [email, setEmail] = useState("");
  const [pw,    setPw]    = useState("");
  const [errors, setErrors] = useState({});

  const handleLogin = () => {
    const errs = {};
    if (!email) errs.email = "이메일을 입력해주세요.";
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = "올바른 이메일 형식이 아닙니다.";
    if (!pw) errs.pw = "비밀번호를 입력해주세요.";
    if (Object.keys(errs).length) { setErrors(errs); return; }
    navigate("mypage");
  };

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 24px" }}>
      <div style={{ width: "100%", maxWidth: 440 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ width: 52, height: 52, background: 색상.main, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, margin: "0 auto 14px" }}>📈</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: "#111827", margin: "0 0 6px" }}>다시 만나서 반가워요!</h1>
          <p style={{ fontSize: 14, color: "#6B7280" }}>목표를 향해 계속 나아가요</p>
        </div>

        <기본카드 style={{ padding: "36px 32px" }}>
          <소셜버튼 emoji="🟡" label="카카오로 로그인"  color="#3A1D1D" bg="#FEE500" />
          <소셜버튼 emoji="🟢" label="네이버로 로그인"  color="#fff"    bg="#03C75A" />
          <소셜버튼 emoji="🔵" label="구글로 로그인" />

          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0" }}>
            <div style={{ flex: 1, height: 1, background: "#E5E7EB" }} />
            <span style={{ fontSize: 12, color: "#9CA3AF" }}>또는 이메일로 로그인</span>
            <div style={{ flex: 1, height: 1, background: "#E5E7EB" }} />
          </div>

          <입력필드 label="이메일"   type="email"    placeholder="example@email.com" value={email} onChange={setEmail} error={errors.email} />
          <입력필드 label="비밀번호" type="password" placeholder="비밀번호 입력"       value={pw}    onChange={setPw}    error={errors.pw} />

          <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 24, marginTop: -8 }}>
            <button style={{ background: "none", border: "none", fontSize: 12, color: 색상.dark, cursor: "pointer", fontFamily: "inherit" }}>비밀번호를 잊으셨나요?</button>
          </div>

          <전체너비버튼 onClick={handleLogin}>로그인</전체너비버튼>

          <p style={{ textAlign: "center", fontSize: 13, color: "#6B7280", marginTop: 20 }}>
            아직 회원이 아니신가요?{" "}
            <button onClick={() => navigate("signup")} style={{ background: "none", border: "none", color: 색상.main, fontWeight: 700, cursor: "pointer", fontSize: 13, fontFamily: "inherit" }}>
              회원가입
            </button>
          </p>
        </기본카드>
      </div>
    </div>
  );
}

// ─── 회원가입 페이지 ──────────────────────────────────────────────
export function 회원가입페이지({ navigate }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: "", email: "", pw: "", pwConfirm: "", agree: false, agreeMarketing: false });
  const [errors, setErrors] = useState({});

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const validate = () => {
    const errs = {};
    if (!form.name.trim())               errs.name      = "이름을 입력해주세요.";
    if (!form.email)                     errs.email     = "이메일을 입력해주세요.";
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = "올바른 이메일 형식이 아닙니다.";
    if (!form.pw)                        errs.pw        = "비밀번호를 입력해주세요.";
    else if (form.pw.length < 8)         errs.pw        = "비밀번호는 8자 이상이어야 합니다.";
    if (form.pw !== form.pwConfirm)      errs.pwConfirm = "비밀번호가 일치하지 않습니다.";
    if (!form.agree)                     errs.agree     = "필수 약관에 동의해주세요.";
    return errs;
  };

  const handleSubmit = () => {
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setStep(2);
  };

  if (step === 2) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 24px" }}>
        <div style={{ textAlign: "center", maxWidth: 400 }}>
          <div style={{ width: 88, height: 88, background: 색상.light, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 44, margin: "0 auto 24px" }}>🎉</div>
          <h2 style={{ fontSize: 26, fontWeight: 800, color: "#111827", margin: "0 0 12px" }}>{form.name}님, 환영해요!</h2>
          <p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 32px" }}>
            목표템 회원이 되셨습니다.<br />지금 바로 첫 번째 목표를 설정해보세요.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <전체너비버튼 onClick={() => navigate("goal")}>첫 목표 설정하기 →</전체너비버튼>
            <기본버튼 onClick={() => navigate("login")} variant="outline" style={{ width: "100%", padding: "14px", fontSize: 14 }}>로그인 페이지로</기본버튼>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 24px" }}>
      <div style={{ width: "100%", maxWidth: 480 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 52, height: 52, background: 색상.main, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, margin: "0 auto 14px" }}>📈</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: "#111827", margin: "0 0 6px" }}>목표템 시작하기</h1>
          <p style={{ fontSize: 14, color: "#6B7280" }}>지금 가입하고 목표를 향해 나아가요</p>
        </div>

        <기본카드 style={{ padding: "36px 32px" }}>
          <소셜버튼 emoji="🟡" label="카카오로 시작하기" color="#3A1D1D" bg="#FEE500" />
          <소셜버튼 emoji="🟢" label="네이버로 시작하기" color="#fff"    bg="#03C75A" />

          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0" }}>
            <div style={{ flex: 1, height: 1, background: "#E5E7EB" }} />
            <span style={{ fontSize: 12, color: "#9CA3AF" }}>또는 이메일로 가입</span>
            <div style={{ flex: 1, height: 1, background: "#E5E7EB" }} />
          </div>

          <입력필드 label="이름"         placeholder="홍길동"             value={form.name}      onChange={(v) => set("name", v)}      error={errors.name} />
          <입력필드 label="이메일"       type="email" placeholder="example@email.com" value={form.email} onChange={(v) => set("email", v)}  error={errors.email} />
          <비밀번호필드 value={form.pw}  onChange={(v) => set("pw", v)}   error={errors.pw} />
          <입력필드 label="비밀번호 확인" type="password" placeholder="비밀번호 재입력" value={form.pwConfirm} onChange={(v) => set("pwConfirm", v)} error={errors.pwConfirm} />

          <약관동의박스
            agree={form.agree} agreeMarketing={form.agreeMarketing}
            onChangeAgree={(v) => set("agree", v)} onChangeMarketing={(v) => set("agreeMarketing", v)}
            error={errors.agree}
          />

          <전체너비버튼 onClick={handleSubmit}>회원가입</전체너비버튼>

          <p style={{ textAlign: "center", fontSize: 13, color: "#6B7280", marginTop: 20 }}>
            이미 계정이 있으신가요?{" "}
            <button onClick={() => navigate("login")} style={{ background: "none", border: "none", color: 색상.main, fontWeight: 700, cursor: "pointer", fontSize: 13, fontFamily: "inherit" }}>
              로그인
            </button>
          </p>
        </기본카드>
      </div>
    </div>
  );
}
