import { useState } from "react";

const steps = ["목표 설정", "지출 업로드", "분석 중", "결과 확인"];

export default function UploadPage({ navigate, goalData }) {
  const [tab, setTab] = useState("file");
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) setFile(f);
  };

  const handleFile = (e) => {
    const f = e.target.files[0];
    if (f) setFile(f);
  };

  const handleAnalyze = () => {
    setAnalyzing(true);
    setTimeout(() => {
      navigate("result", goalData);
    }, 2000);
  };

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "60px 24px" }}>
      <div style={{ width: "100%", maxWidth: 560 }}>
        {/* Step Indicator */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 40 }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: i <= 1 ? "#22C55E" : "#E5E7EB",
                  color: i <= 1 ? "#fff" : "#9CA3AF",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 14, fontWeight: 600,
                }}>
                  {i === 0 ? "✓" : i === 1 ? "📤" : i + 1}
                </div>
                <span style={{ fontSize: 11, color: i === 1 ? "#22C55E" : i === 0 ? "#22C55E" : "#9CA3AF", fontWeight: i <= 1 ? 600 : 400, whiteSpace: "nowrap" }}>{s}</span>
              </div>
              {i < steps.length - 1 && (
                <div style={{ width: 60, height: 2, background: i === 0 ? "#22C55E" : "#E5E7EB", margin: "0 4px", marginBottom: 20 }} />
              )}
            </div>
          ))}
        </div>

        <div style={{
          background: "#fff", borderRadius: 20,
          padding: "40px 36px",
          boxShadow: "0 2px 16px rgba(0,0,0,0.06)",
        }}>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: "#111827", margin: "0 0 28px" }}>
            지출 내역을 입력해주세요
          </h2>

          {/* Tabs */}
          <div style={{ display: "flex", marginBottom: 28, border: "1.5px solid #E5E7EB", borderRadius: 10, overflow: "hidden" }}>
            {["file", "direct"].map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                style={{
                  flex: 1, padding: "12px",
                  background: tab === t ? "#22C55E" : "#fff",
                  color: tab === t ? "#fff" : "#374151",
                  border: "none", cursor: "pointer",
                  fontSize: 14, fontWeight: 600,
                }}
              >
                {t === "file" ? "파일 업로드" : "직접 입력"}
              </button>
            ))}
          </div>

          {tab === "file" ? (
            <div>
              <div
                onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                onDragLeave={() => setDragging(false)}
                onDrop={handleDrop}
                onClick={() => document.getElementById("fileInput").click()}
                style={{
                  border: `2px dashed ${dragging ? "#22C55E" : file ? "#22C55E" : "#D1D5DB"}`,
                  borderRadius: 14,
                  padding: "48px 24px",
                  textAlign: "center",
                  cursor: "pointer",
                  background: dragging ? "#F0FDF4" : file ? "#F0FDF4" : "#FAFAFA",
                  transition: "all 0.2s",
                }}
              >
                <div style={{ fontSize: 40, marginBottom: 12 }}>{file ? "✅" : "📄"}</div>
                {file ? (
                  <div>
                    <p style={{ fontSize: 15, fontWeight: 600, color: "#22C55E", margin: "0 0 4px" }}>{file.name}</p>
                    <p style={{ fontSize: 13, color: "#6B7280", margin: 0 }}>파일이 선택되었습니다</p>
                  </div>
                ) : (
                  <div>
                    <p style={{ fontSize: 15, color: "#374151", margin: "0 0 6px", fontWeight: 500 }}>
                      파일을 드래그하거나 클릭하여 업로드
                    </p>
                    <p style={{ fontSize: 13, color: "#9CA3AF", margin: 0 }}>CSV, 엑셀 파일만 가능</p>
                  </div>
                )}
                <input id="fileInput" type="file" accept=".csv,.xlsx,.xls" style={{ display: "none" }} onChange={handleFile} />
              </div>
              <p style={{ fontSize: 12, color: "#9CA3AF", marginTop: 12 }}>
                ※ 카드사나 은행에서 다운로드한 내역 파일을 사용해주세요.
              </p>
            </div>
          ) : (
            <div>
              <textarea
                placeholder="날짜, 금액, 카테고리 형식으로 입력해주세요&#10;예) 2024-01-01, 12000, 카페"
                rows={8}
                style={{
                  width: "100%", padding: "14px 16px",
                  border: "1.5px solid #E5E7EB", borderRadius: 10,
                  fontSize: 14, outline: "none", resize: "vertical",
                  boxSizing: "border-box", color: "#111827", lineHeight: 1.6,
                }}
              />
            </div>
          )}

          {analyzing && (
            <div style={{
              textAlign: "center", padding: "20px 0",
              color: "#22C55E", fontWeight: 600, fontSize: 15,
            }}>
              ⏳ 분석 중...
            </div>
          )}

          <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
            <button
              onClick={() => navigate("goal")}
              style={{
                flex: 1, padding: "14px",
                background: "#fff", color: "#374151",
                border: "1.5px solid #D1D5DB", borderRadius: 10,
                fontSize: 15, fontWeight: 600, cursor: "pointer",
              }}
            >이전</button>
            <button
              onClick={handleAnalyze}
              disabled={analyzing}
              style={{
                flex: 2, padding: "14px",
                background: analyzing ? "#86EFAC" : "#22C55E",
                color: "#fff", border: "none", borderRadius: 10,
                fontSize: 15, fontWeight: 700, cursor: analyzing ? "not-allowed" : "pointer",
              }}
            >분석 시작</button>
          </div>
        </div>
      </div>
    </div>
  );
}
