const spending = [
  { label: "식비", pct: 40, color: "#22C55E", amount: 120000 },
  { label: "카페/간식", pct: 20, color: "#86EFAC", amount: 60000 },
  { label: "교통", pct: 15, color: "#FCD34D", amount: 45000 },
  { label: "쇼핑", pct: 15, color: "#F87171", amount: 45000 },
  { label: "기타", pct: 10, color: "#93C5FD", amount: 30000 },
];

const tips = [
  { icon: "🍜", text: "배달비를 월 5만원 줄이면 3개월 내 목표 달성 가능!" },
  { icon: "☕", text: "카페 이용을 주 2회 줄이면 월 2만원 절약 가능!" },
  { icon: "📦", text: "불필요한 구독 서비스를 점검해보세요! 월 1만원 이상 절약 가능!" },
];

export default function ResultPage({ navigate, goalData }) {
  const goal = goalData || { itemName: "게이밍 헤드셋", amount: 300000, period: "5개월" };
  const saved = Math.round(goal.amount * 0.4);
  const remaining = goal.amount - saved;
  const pct = Math.round((saved / goal.amount) * 100);

  // Simple donut chart via SVG
  const radius = 60;
  const cx = 80, cy = 80;
  let offset = 0;
  const arcs = spending.map((s) => {
    const start = offset;
    offset += s.pct;
    return { ...s, start };
  });

  const polarToCartesian = (cx, cy, r, angle) => {
    const rad = (angle - 90) * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const describeArc = (cx, cy, r, startPct, endPct) => {
    const s = polarToCartesian(cx, cy, r, startPct * 3.6);
    const e = polarToCartesian(cx, cy, r, endPct * 3.6);
    const large = endPct - startPct > 50 ? 1 : 0;
    return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
  };

  return (
    <div style={{ background: "#F3F4F6", minHeight: "calc(100vh - 64px)", padding: "40px 24px" }}>
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <div style={{
          background: "#fff", borderRadius: 20,
          padding: "20px 24px 12px",
          marginBottom: 20,
          boxShadow: "0 2px 12px rgba(0,0,0,0.05)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 22, fontWeight: 700, color: "#111827" }}>📈 목표템</span>
          </div>
          <div style={{ display: "flex", gap: 20 }}>
            <button onClick={() => navigate("main")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 14, color: "#6B7280" }}>홈</button>
            <button onClick={() => navigate("mypage")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 14, color: "#22C55E", fontWeight: 600 }}>마이페이지</button>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#E5E7EB", display: "flex", alignItems: "center", justifyContent: "center" }}>👤</div>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {/* Goal Achievement */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "28px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 20px" }}>목표 달성 예측</h3>
            <div style={{ marginBottom: 8 }}>
              <span style={{ fontSize: 13, color: "#9CA3AF" }}>목표 금액</span>
              <p style={{ fontSize: 24, fontWeight: 700, color: "#111827", margin: "4px 0" }}>
                {goal.amount.toLocaleString()}원
              </p>
            </div>
            <div style={{ marginBottom: 20 }}>
              <span style={{ fontSize: 13, color: "#9CA3AF" }}>현재 모은 금액</span>
              <p style={{ fontSize: 18, fontWeight: 600, color: "#374151", margin: "4px 0" }}>
                {saved.toLocaleString()}원 ({pct}%)
              </p>
            </div>
            <div style={{ height: 10, background: "#E5E7EB", borderRadius: 999, overflow: "hidden", marginBottom: 24 }}>
              <div style={{ height: "100%", width: `${pct}%`, background: "#22C55E", borderRadius: 999 }} />
            </div>
            <div style={{ borderTop: "1px solid #F3F4F6", paddingTop: 20 }}>
              <span style={{ fontSize: 13, color: "#9CA3AF" }}>목표 달성 예상 기간</span>
              <p style={{ fontSize: 44, fontWeight: 800, color: "#22C55E", margin: "4px 0" }}>5개월</p>
              <p style={{ fontSize: 13, color: "#6B7280" }}>현재 소비 패턴으로는 5개월 후 목표를 달성할 수 있어요!</p>
            </div>
          </div>

          {/* Spending Chart */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "28px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 20px" }}>소비 패턴 (월 평균)</h3>
            <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <svg width={160} height={160} viewBox="0 0 160 160">
                {arcs.map((arc, i) => (
                  <path
                    key={i}
                    d={describeArc(cx, cy, radius, arc.start, arc.start + arc.pct)}
                    fill="none"
                    stroke={arc.color}
                    strokeWidth={20}
                  />
                ))}
                <circle cx={cx} cy={cy} r={44} fill="#fff" />
                <text x={cx} y={cy - 4} textAnchor="middle" fontSize={12} fill="#9CA3AF">총 지출</text>
                <text x={cx} y={cy + 14} textAnchor="middle" fontSize={15} fontWeight="700" fill="#111827">30만원</text>
              </svg>
              <div style={{ flex: 1 }}>
                {spending.map((s) => (
                  <div key={s.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 10, height: 10, borderRadius: "50%", background: s.color }} />
                      <span style={{ fontSize: 13, color: "#374151" }}>{s.label} {s.pct}%</span>
                    </div>
                    <span style={{ fontSize: 12, color: "#6B7280" }}>{s.amount.toLocaleString()}원</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* AI Tips */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "28px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)", gridColumn: "1 / -1" }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 20px" }}>AI 절약 추천</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
              {tips.map((tip, i) => (
                <div key={i} style={{
                  background: "#F0FDF4", borderRadius: 14,
                  padding: "20px", display: "flex", gap: 12, alignItems: "flex-start",
                }}>
                  <span style={{ fontSize: 28 }}>{tip.icon}</span>
                  <p style={{ fontSize: 14, color: "#166534", margin: 0, lineHeight: 1.6, fontWeight: 500 }}>{tip.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
          <button
            onClick={() => navigate("goal")}
            style={{
              padding: "14px 28px", borderRadius: 10,
              border: "1.5px solid #D1D5DB", background: "#fff",
              fontSize: 14, fontWeight: 600, cursor: "pointer", color: "#374151",
            }}
          >새 목표 설정</button>
          <button
            onClick={() => navigate("mypage")}
            style={{
              padding: "14px 28px", borderRadius: 10,
              background: "#22C55E", color: "#fff",
              border: "none", fontSize: 14, fontWeight: 700, cursor: "pointer",
            }}
          >마이페이지로 →</button>
        </div>
      </div>
    </div>
  );
}
