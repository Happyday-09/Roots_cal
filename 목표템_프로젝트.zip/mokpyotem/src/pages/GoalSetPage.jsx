import { useState } from "react";

const steps = ["목표 설정", "지출 업로드", "분석 중", "결과 확인"];

export default function GoalSetPage({ navigate }) {
  const [itemName, setItemName] = useState("");
  const [amount, setAmount] = useState("300,000");
  const [period, setPeriod] = useState("3개월");

  const handleSubmit = () => {
    if (!itemName.trim()) return alert("물건 이름을 입력해주세요.");
    navigate("upload", {
      itemName,
      amount: parseInt(amount.replace(/,/g, "")) || 300000,
      period,
    });
  };

  const formatAmount = (v) => {
    const num = v.replace(/[^0-9]/g, "");
    return num.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  return (
    <div style={{ minHeight: "calc(100vh - 64px)", background: "#F3F4F6", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "60px 24px" }}>
      <div style={{ width: "100%", maxWidth: 520 }}>
        {/* Step Indicator */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 40 }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: i === 0 ? "#22C55E" : "#E5E7EB",
                  color: i === 0 ? "#fff" : "#9CA3AF",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 14, fontWeight: 600,
                }}>
                  {i === 0 ? "✓" : i + 1}
                </div>
                <span style={{ fontSize: 11, color: i === 0 ? "#22C55E" : "#9CA3AF", fontWeight: i === 0 ? 600 : 400, whiteSpace: "nowrap" }}>{s}</span>
              </div>
              {i < steps.length - 1 && (
                <div style={{ width: 60, height: 2, background: "#E5E7EB", margin: "0 4px", marginBottom: 20 }} />
              )}
            </div>
          ))}
        </div>

        {/* Form Card */}
        <div style={{
          background: "#fff",
          borderRadius: 20,
          padding: "40px 36px",
          boxShadow: "0 2px 16px rgba(0,0,0,0.06)",
        }}>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: "#111827", margin: "0 0 32px" }}>
            목표하는 물건을 입력해주세요
          </h2>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>
              물건 이름
            </label>
            <input
              type="text"
              placeholder="예) 게이밍 헤드셋"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              style={{
                width: "100%", padding: "12px 16px",
                border: "1.5px solid #E5E7EB", borderRadius: 10,
                fontSize: 15, outline: "none", boxSizing: "border-box",
                color: "#111827",
              }}
              onFocus={(e) => e.target.style.borderColor = "#22C55E"}
              onBlur={(e) => e.target.style.borderColor = "#E5E7EB"}
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>
              목표 금액
            </label>
            <div style={{ position: "relative" }}>
              <input
                type="text"
                value={amount}
                onChange={(e) => setAmount(formatAmount(e.target.value))}
                style={{
                  width: "100%", padding: "12px 48px 12px 16px",
                  border: "1.5px solid #E5E7EB", borderRadius: 10,
                  fontSize: 15, outline: "none", boxSizing: "border-box",
                  color: "#111827",
                }}
                onFocus={(e) => e.target.style.borderColor = "#22C55E"}
                onBlur={(e) => e.target.style.borderColor = "#E5E7EB"}
              />
              <span style={{
                position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)",
                fontSize: 15, color: "#6B7280",
              }}>원</span>
            </div>
          </div>

          <div style={{ marginBottom: 36 }}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 8 }}>
              원하는 기간
            </label>
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              style={{
                width: "100%", padding: "12px 16px",
                border: "1.5px solid #E5E7EB", borderRadius: 10,
                fontSize: 15, outline: "none", background: "#fff",
                color: "#111827", cursor: "pointer",
              }}
            >
              {["1개월", "2개월", "3개월", "4개월", "5개월", "6개월", "12개월"].map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          <button
            onClick={handleSubmit}
            style={{
              width: "100%", padding: "16px",
              background: "#22C55E", color: "#fff",
              border: "none", borderRadius: 10,
              fontSize: 16, fontWeight: 700, cursor: "pointer",
            }}
          >
            다음
          </button>
        </div>
      </div>
    </div>
  );
}
