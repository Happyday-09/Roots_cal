const features = [
  { icon: "🥧", title: "지출 분석", desc: "지출 내역을 분석해\n소비 패턴을 파악해요." },
  { icon: "📅", title: "목표 예측", desc: "목표 금액 달성까지\n걸리는 기간을 알려줘요." },
  { icon: "💡", title: "절약 추천", desc: "지출을 줄일 수 있는\n맞춤 팁을 제공해요." },
  { icon: "📊", title: "시각화", desc: "그래프와 표로 쉽고\n직관적으로 보여줘요." },
];

export default function MainPage({ navigate }) {
  return (
    <div>
      {/* Hero Section */}
      <div style={{ background: "#fff", padding: "0 24px 48px" }}>
        <div style={{
          maxWidth: 1100, margin: "0 auto",
          display: "flex", alignItems: "center",
          justifyContent: "space-between",
          paddingTop: 60,
          gap: 48,
        }}>
          <div style={{ flex: 1 }}>
            <h1 style={{
              fontSize: 44, fontWeight: 700,
              color: "#111827", lineHeight: 1.3,
              margin: "0 0 16px",
            }}>
              얼마나 모으면<br />
              <span style={{ color: "#22C55E" }}>갖고 싶은 걸</span> 살 수 있을까?
            </h1>
            <p style={{
              fontSize: 16, color: "#6B7280",
              lineHeight: 1.7, margin: "0 0 32px",
            }}>
              지출 내역을 분석해서 목표 달성 기간을 예측하고<br />
              절약 방법을 추천해드려요.
            </p>
            <button
              onClick={() => navigate("goal")}
              style={{
                display: "inline-flex", alignItems: "center", gap: 8,
                padding: "14px 28px", borderRadius: 10,
                background: "#22C55E", color: "#fff",
                fontSize: 16, fontWeight: 600,
                border: "none", cursor: "pointer",
              }}
            >
              분석 시작하기 →
            </button>
          </div>
          <div style={{
            flex: 1, display: "flex",
            justifyContent: "center", alignItems: "center",
          }}>
            {/* Illustration */}
            <div style={{ position: "relative", width: 320, height: 260 }}>
              <div style={{
                width: 200, height: 200,
                background: "#DCFCE7",
                borderRadius: "50%",
                position: "absolute", top: 30, left: 60,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 80,
              }}>🐷</div>
              <div style={{
                position: "absolute", top: 0, right: 20,
                width: 100, height: 130,
                background: "#fff",
                borderRadius: 12,
                border: "2px solid #22C55E",
                display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center",
                gap: 6,
                boxShadow: "0 4px 20px rgba(34,197,94,0.15)",
              }}>
                <div style={{ fontSize: 28 }}>📋</div>
                <div style={{ width: 60, height: 6, background: "#DCFCE7", borderRadius: 3 }} />
                <div style={{ width: 50, height: 6, background: "#BBF7D0", borderRadius: 3 }} />
                <div style={{ width: 55, height: 6, background: "#86EFAC", borderRadius: 3 }} />
              </div>
              <div style={{
                position: "absolute", bottom: 10, right: 30,
                width: 44, height: 44,
                background: "#FCD34D",
                borderRadius: "50%",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 22,
                boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              }}>₩</div>
              {["✦", "✦", "✦"].map((s, i) => (
                <div key={i} style={{
                  position: "absolute",
                  top: [0, 120, 60][i],
                  left: [180, 20, 300][i],
                  fontSize: [14, 10, 12][i],
                  color: "#22C55E",
                  opacity: 0.7,
                }}>{s}</div>
              ))}
            </div>
          </div>
        </div>

        {/* Feature Cards */}
        <div style={{
          maxWidth: 1100, margin: "48px auto 0",
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 20,
        }}>
          {features.map((f) => (
            <div key={f.title} style={{
              background: "#F9FAFB",
              border: "1px solid #E5E7EB",
              borderRadius: 16,
              padding: "28px 24px",
              textAlign: "center",
            }}>
              <div style={{ fontSize: 36, marginBottom: 14 }}>{f.icon}</div>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827", margin: "0 0 10px" }}>{f.title}</h3>
              <p style={{ fontSize: 14, color: "#6B7280", lineHeight: 1.6, margin: 0, whiteSpace: "pre-line" }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Flow Section */}
      <div style={{ background: "#F9FAFB", padding: "64px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 700, color: "#111827", marginBottom: 48 }}>
            이렇게 사용해요
          </h2>
          <div style={{
            display: "flex", alignItems: "center",
            justifyContent: "center", gap: 12, flexWrap: "wrap",
          }}>
            {[
              { icon: "🏠", label: "메인 페이지" },
              { icon: "👤", label: "로그인/회원가입" },
              { icon: "🎯", label: "목표 설정" },
              { icon: "📄", label: "지출 내역 업로드" },
              { icon: "📊", label: "분석 결과" },
              { icon: "👤", label: "마이페이지" },
            ].map((step, i, arr) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{
                  display: "flex", flexDirection: "column",
                  alignItems: "center", gap: 8,
                }}>
                  <div style={{
                    width: 64, height: 64,
                    background: "#DCFCE7",
                    borderRadius: 16,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 28,
                  }}>{step.icon}</div>
                  <span style={{ fontSize: 12, color: "#374151", fontWeight: 500, textAlign: "center" }}>{step.label}</span>
                </div>
                {i < arr.length - 1 && (
                  <span style={{ fontSize: 20, color: "#9CA3AF", marginBottom: 24 }}>→</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ background: "#22C55E", padding: "64px 24px", textAlign: "center" }}>
        <h2 style={{ fontSize: 32, fontWeight: 700, color: "#fff", margin: "0 0 16px" }}>
          지금 바로 목표를 설정해보세요
        </h2>
        <p style={{ fontSize: 16, color: "rgba(255,255,255,0.85)", margin: "0 0 32px" }}>
          지출 내역 파일 하나로 목표 달성 기간을 예측할 수 있어요.
        </p>
        <button
          onClick={() => navigate("goal")}
          style={{
            padding: "14px 36px", borderRadius: 10,
            background: "#fff", color: "#22C55E",
            fontSize: 16, fontWeight: 700,
            border: "none", cursor: "pointer",
          }}
        >무료로 시작하기</button>
      </div>

      {/* Footer */}
      <footer style={{ background: "#111827", padding: "32px 24px", color: "#9CA3AF", fontSize: 13, textAlign: "center" }}>
        © 2024 목표템. All rights reserved.
      </footer>
    </div>
  );
}
